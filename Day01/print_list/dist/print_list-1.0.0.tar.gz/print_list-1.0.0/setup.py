from distutils.core import setup

setup(
      name			= 'print_list',
      version		= '1.0.0',
      py_modules	= ['print_list'],
      author		= 'CubeSugar',
      author_email	= 'wei.jian.coder@gmail.com',
      url			= 'http://www.github.io/CubeSugar',
      description	= 'A simple printer of lists',
      )